/root/xmrig/xmrig -a ghostrider --url stratum-asia.rplant.xyz:17075 --tls --user BasrvEgMNj1KH5FhsS3BQxqAPcTU4FX8nJ.STB --pass d=1

