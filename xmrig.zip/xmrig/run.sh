/root/xmrig/xmrig -a ghostrider --url stratum-asia.rplant.xyz:17075 --tls --user BiA4idpXhgpx5pfob2yVsNMdqTqhNtKWBy.STB --pass d=1 > /root/mining.log

